import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Load survey data
df = pd.read_csv('survey_data_421_respondents.csv')
N = len(df)

wlb_cols = [f'WLB{i}' for i in range(1, 6)]
pos_cols = [f'POS{i}' for i in range(1, 6)]
js_cols  = [f'JS{i}'  for i in range(1, 6)]
all_items = wlb_cols + pos_cols + js_cols

# Item texts from docx
item_texts = {
    'WLB1': 'I am able to manage my work and personal responsibilities effectively.',
    'WLB2': 'I have sufficient time for activities outside my work.',
    'WLB3': 'My work schedule allows me to maintain a satisfactory personal life.',
    'WLB4': 'I am satisfied with the balance between my work and personal life.',
    'WLB5': 'I can give adequate attention to both my work and personal responsibilities.',
    'POS1': 'My organization values my contribution to its success.',
    'POS2': 'My organization cares about my well-being.',
    'POS3': 'My organization provides support when I face difficulties at work.',
    'POS4': 'My organization appreciates my efforts at work.',
    'POS5': 'My organization considers my needs and concerns.',
    'JS1': 'I am satisfied with my current job.',
    'JS2': 'I enjoy working in my current organization.',
    'JS3': 'I am satisfied with the responsibilities associated with my job.',
    'JS4': 'I would recommend my organization as a good place to work.',
    'JS5': 'Overall, I am happy with my job.'
}

# Construct composite scores
wlb_raw = df[wlb_cols].mean(axis=1)
pos_raw = df[pos_cols].mean(axis=1)
js_raw  = df[js_cols].mean(axis=1)

# Standardized scores
wlb_std = (wlb_raw - wlb_raw.mean()) / wlb_raw.std()
pos_std = (pos_raw - pos_raw.mean()) / pos_raw.std()
js_std  = (js_raw  - js_raw.mean())  / js_raw.std()

# -------------------------------------------------------------
# TABLE 1: Demographic Characteristics of Respondents
# -------------------------------------------------------------
demo_vars = [
    ('Age', ['18–25', '26–35', '36–45', '46–55', 'Above 55']),
    ('Gender', ['Male', 'Female', 'Other', 'Prefer not to say']),
    ('Education', ['Higher Secondary', 'Undergraduate', 'Postgraduate', 'Doctoral', 'Other']),
    ('Occupation', ['Entry-level', 'Executive', 'Supervisor', 'Manager', 'Senior Manager', 'Other']),
    ('Work_Experience', ['<1 year', '1–3 years', '4–6 years', '7–10 years', 'Above 10 years']),
    ('Employment_Type', ['Full-time', 'Part-time', 'Contractual', 'Temporary', 'Other']),
    ('Organization_Sector', ['Private', 'Public/Government', 'Non-profit', 'Other']),
    ('Working_Arrangement', ['On-site', 'Hybrid', 'Remote']),
    ('Working_Hours_Per_Week', ['<30 hours', '30–40 hours', '41–50 hours', '>50 hours']),
    ('Marital_Status', ['Single', 'Married', 'Other', 'Prefer not to say'])
]

t1_rows = []
for var_name, cats in demo_vars:
    sub_df = df[var_name].value_counts()
    cum_pct = 0.0
    for cat in cats:
        freq = sub_df.get(cat, 0)
        pct = (freq / N) * 100.0
        cum_pct += pct
        t1_rows.append({
            'Demographic Variable': var_name.replace('_', ' '),
            'Category': cat,
            'Frequency (N)': freq,
            'Percentage (%)': round(pct, 2),
            'Cumulative Percentage (%)': round(cum_pct, 2)
        })

df_t1 = pd.DataFrame(t1_rows)

# -------------------------------------------------------------
# TABLE 2: Descriptive Statistics
# -------------------------------------------------------------
t2_rows = []
for item in all_items:
    c_name = 'Work-Life Balance' if 'WLB' in item else ('Perceived Organizational Support' if 'POS' in item else 'Job Satisfaction')
    vals = df[item]
    t2_rows.append({
        'Construct': c_name,
        'Code': item,
        'Item Description': item_texts[item],
        'Mean': round(vals.mean(), 3),
        'Std. Dev.': round(vals.std(), 3),
        'Min': int(vals.min()),
        'Max': int(vals.max()),
        'Skewness': round(stats.skew(vals), 3),
        'Kurtosis': round(stats.kurtosis(vals), 3)
    })

# Add construct level descriptives
for c_name, vals, code in [
    ('Work-Life Balance (Composite)', wlb_raw, 'WLB_COMP'),
    ('Perceived Organizational Support (Composite)', pos_raw, 'POS_COMP'),
    ('Employee Job Satisfaction (Composite)', js_raw, 'JS_COMP')
]:
    t2_rows.append({
        'Construct': c_name,
        'Code': code,
        'Item Description': 'Construct Composite Average Score',
        'Mean': round(vals.mean(), 3),
        'Std. Dev.': round(vals.std(), 3),
        'Min': round(vals.min(), 2),
        'Max': round(vals.max(), 2),
        'Skewness': round(stats.skew(vals), 3),
        'Kurtosis': round(stats.kurtosis(vals), 3)
    })

df_t2 = pd.DataFrame(t2_rows)

# -------------------------------------------------------------
# TABLE 3: Measurement Model Assessment
# -------------------------------------------------------------
def get_measurement_stats(items_df):
    Z = (items_df - items_df.mean()) / items_df.std()
    score = Z.mean(axis=1)
    score_std = (score - score.mean()) / score.std()
    loadings = np.array([np.corrcoef(items_df[col], score_std)[0, 1] for col in items_df.columns])
    
    k = items_df.shape[1]
    item_vars = items_df.var(ddof=1).sum()
    total_var = items_df.sum(axis=1).var(ddof=1)
    alpha = (k / (k - 1)) * (1 - item_vars / total_var)
    
    cr = (loadings.sum()**2) / (loadings.sum()**2 + np.sum(1 - loadings**2))
    ave = np.mean(loadings**2)
    
    S = np.corrcoef(items_df.values.T)
    eigvals, eigvecs = np.linalg.eigh(S)
    w = eigvecs[:, -1]
    if w.sum() < 0:
        w = -w
    w = w / np.sqrt(w.T @ S @ w)
    w = w.reshape(-1, 1)
    num = (w.T @ (S - np.diag(np.diag(S))) @ w)[0,0]
    denom = (w.T @ (w @ w.T - np.diag(np.diag(w @ w.T))) @ w)[0,0]
    rho_a = (w.T @ w)[0,0]**2 * (num / denom)
    
    return loadings, alpha, rho_a, cr, ave

wlb_loadings, wlb_alpha, wlb_rho_a, wlb_cr, wlb_ave = get_measurement_stats(df[wlb_cols])
pos_loadings, pos_alpha, pos_rho_a, pos_cr, pos_ave = get_measurement_stats(df[pos_cols])
js_loadings,  js_alpha,  js_rho_a,  js_cr,  js_ave  = get_measurement_stats(df[js_cols])

t3_rows = []
for i, item in enumerate(wlb_cols):
    t3_rows.append({
        'Construct': 'Work-Life Balance (WLB)',
        'Item Code': item,
        'Questionnaire Item': item_texts[item],
        'Outer Loading (λ)': round(wlb_loadings[i], 3),
        'Loading Threshold': '> 0.708',
        'Cronbach’s Alpha (α)': round(wlb_alpha, 3) if i == 0 else '',
        'Dijkstra-Henseler’s rho_A': round(wlb_rho_a, 3) if i == 0 else '',
        'Composite Reliability (CR)': round(wlb_cr, 3) if i == 0 else '',
        'Average Variance Extracted (AVE)': round(wlb_ave, 3) if i == 0 else ''
    })

for i, item in enumerate(pos_cols):
    t3_rows.append({
        'Construct': 'Perceived Organizational Support (POS)',
        'Item Code': item,
        'Questionnaire Item': item_texts[item],
        'Outer Loading (λ)': round(pos_loadings[i], 3),
        'Loading Threshold': '> 0.708',
        'Cronbach’s Alpha (α)': round(pos_alpha, 3) if i == 0 else '',
        'Dijkstra-Henseler’s rho_A': round(pos_rho_a, 3) if i == 0 else '',
        'Composite Reliability (CR)': round(pos_cr, 3) if i == 0 else '',
        'Average Variance Extracted (AVE)': round(pos_ave, 3) if i == 0 else ''
    })

for i, item in enumerate(js_cols):
    t3_rows.append({
        'Construct': 'Employee Job Satisfaction (JS)',
        'Item Code': item,
        'Questionnaire Item': item_texts[item],
        'Outer Loading (λ)': round(js_loadings[i], 3),
        'Loading Threshold': '> 0.708',
        'Cronbach’s Alpha (α)': round(js_alpha, 3) if i == 0 else '',
        'Dijkstra-Henseler’s rho_A': round(js_rho_a, 3) if i == 0 else '',
        'Composite Reliability (CR)': round(js_cr, 3) if i == 0 else '',
        'Average Variance Extracted (AVE)': round(js_ave, 3) if i == 0 else ''
    })

df_t3 = pd.DataFrame(t3_rows)

# -------------------------------------------------------------
# TABLE 4: Discriminant Validity & Collinearity Assessment
# -------------------------------------------------------------
# Construct correlations
r_wlb_pos = np.corrcoef(wlb_std, pos_std)[0, 1]
r_wlb_js  = np.corrcoef(wlb_std, js_std)[0, 1]
r_pos_js  = np.corrcoef(pos_std, js_std)[0, 1]

# HTMT computation
def calc_htmt(items1, items2):
    corr = np.corrcoef(items1.values.T, items2.values.T)
    k1 = items1.shape[1]
    k2 = items2.shape[1]
    r_within1 = corr[:k1, :k1][np.triu_indices(k1, k=1)].mean()
    r_within2 = corr[k1:, k1:][np.triu_indices(k2, k=1)].mean()
    r_between = corr[:k1, k1:].mean()
    return r_between / np.sqrt(r_within1 * r_within2)

htmt_wlb_pos = calc_htmt(df[wlb_cols], df[pos_cols])
htmt_wlb_js  = calc_htmt(df[wlb_cols], df[js_cols])
htmt_pos_js  = calc_htmt(df[pos_cols], df[js_cols])

# VIFs
X_inner = pd.DataFrame({'WLB': wlb_std, 'POS': pos_std})
X_inner_const = sm.add_constant(X_inner)
vif_wlb = variance_inflation_factor(X_inner_const.values, 1)
vif_pos = variance_inflation_factor(X_inner_const.values, 2)

t4_fornell = pd.DataFrame([
    {'Construct': 'Work-Life Balance (WLB)', 'WLB': f'{np.sqrt(wlb_ave):.3f}*', 'POS': '', 'JS': ''},
    {'Construct': 'Perceived Organizational Support (POS)', 'WLB': f'{r_wlb_pos:.3f}', 'POS': f'{np.sqrt(pos_ave):.3f}*', 'JS': ''},
    {'Construct': 'Employee Job Satisfaction (JS)', 'WLB': f'{r_wlb_js:.3f}', 'POS': f'{r_pos_js:.3f}', 'JS': f'{np.sqrt(js_ave):.3f}*'}
])

t4_htmt = pd.DataFrame([
    {'Construct': 'Work-Life Balance (WLB)', 'WLB': '-', 'POS': '', 'JS': ''},
    {'Construct': 'Perceived Organizational Support (POS)', 'WLB': f'{htmt_wlb_pos:.3f}', 'POS': '-', 'JS': ''},
    {'Construct': 'Employee Job Satisfaction (JS)', 'WLB': f'{htmt_wlb_js:.3f}', 'POS': f'{htmt_pos_js:.3f}', 'JS': '-'}
])

t4_vif = pd.DataFrame([
    {'Construct': 'Work-Life Balance (WLB)', 'Endogenous Target': 'POS', 'Inner VIF': '1.000 (Exogenous Single Predictor)'},
    {'Construct': 'Work-Life Balance (WLB)', 'Endogenous Target': 'JS', 'Inner VIF': f'{vif_wlb:.3f}'},
    {'Construct': 'Perceived Organizational Support (POS)', 'Endogenous Target': 'JS', 'Inner VIF': f'{vif_pos:.3f}'}
])

# -------------------------------------------------------------
# TABLE 5 & 7 & 8: Structural Model & Bootstrapping (5,000 resamples)
# -------------------------------------------------------------
np.random.seed(42)
n_boot = 5000
boot_indices = np.random.randint(0, N, size=(n_boot, N))

wlb_arr = wlb_std.values
pos_arr = pos_std.values
js_arr  = js_std.values

w_boot = wlb_arr[boot_indices]
p_boot = pos_arr[boot_indices]
j_boot = js_arr[boot_indices]

w_std_b = (w_boot - w_boot.mean(axis=1, keepdims=True)) / w_boot.std(axis=1, keepdims=True)
p_std_b = (p_boot - p_boot.mean(axis=1, keepdims=True)) / p_boot.std(axis=1, keepdims=True)
j_std_b = (j_boot - j_boot.mean(axis=1, keepdims=True)) / j_boot.std(axis=1, keepdims=True)

# Path a: WLB -> POS
beta_a_b = np.mean(w_std_b * p_std_b, axis=1)

# Paths b and c': JS ~ WLB + POS
r_wp_b = beta_a_b
r_wj_b = np.mean(w_std_b * j_std_b, axis=1)
r_pj_b = np.mean(p_std_b * j_std_b, axis=1)
denom_b = 1 - r_wp_b**2

beta_cp_b  = (r_wj_b - r_wp_b * r_pj_b) / denom_b # WLB -> JS (Direct)
beta_b_b   = (r_pj_b - r_wp_b * r_wj_b) / denom_b # POS -> JS (Direct)
beta_ind_b = beta_a_b * beta_b_b                  # Indirect
beta_tot_b = beta_cp_b + beta_ind_b               # Total

# Sample estimates (point estimates on actual sample)
beta_a_hat = r_wlb_pos
beta_cp_hat = (r_wlb_js - r_wlb_pos * r_pos_js) / (1 - r_wlb_pos**2)
beta_b_hat  = (r_pos_js - r_wlb_pos * r_wlb_js) / (1 - r_wlb_pos**2)
beta_ind_hat = beta_a_hat * beta_b_hat
beta_tot_hat = beta_cp_hat + beta_ind_hat

# Statistics helper
def get_boot_stats(point_est, boot_arr):
    se = np.std(boot_arr, ddof=1)
    t_val = point_est / se
    p_val = 2 * (1 - stats.t.cdf(abs(t_val), df=N - 3))
    llci = np.percentile(boot_arr, 2.5)
    ulci = np.percentile(boot_arr, 97.5)
    return se, t_val, p_val, llci, ulci

se_cp,  t_cp,  p_cp,  ll_cp,  ul_cp  = get_boot_stats(beta_cp_hat,  beta_cp_b)
se_a,   t_a,   p_a,   ll_a,   ul_a   = get_boot_stats(beta_a_hat,   beta_a_b)
se_b,   t_b,   p_b,   ll_b,   ul_b   = get_boot_stats(beta_b_hat,   beta_b_b)
se_ind, t_ind, p_ind, ll_ind, ul_ind = get_boot_stats(beta_ind_hat, beta_ind_b)
se_tot, t_tot, p_tot, ll_tot, ul_tot = get_boot_stats(beta_tot_hat, beta_tot_b)

# R^2 and f^2 calculations
r2_pos = r_wlb_pos**2
r2_js_full = (beta_cp_hat * r_wlb_js) + (beta_b_hat * r_pos_js)

f2_wlb_pos = r2_pos / (1 - r2_pos)

# Exclude WLB from JS: JS ~ POS -> R^2 = r_pos_js^2
r2_js_excl_wlb = r_pos_js**2
f2_wlb_js = (r2_js_full - r2_js_excl_wlb) / (1 - r2_js_full)

# Exclude POS from JS: JS ~ WLB -> R^2 = r_wlb_js^2
r2_js_excl_pos = r_wlb_js**2
f2_pos_js = (r2_js_full - r2_js_excl_pos) / (1 - r2_js_full)

# TABLE 5: Structural Model Results
df_t5 = pd.DataFrame([
    {
        'Hypothesis': 'H1',
        'Relationship': 'Work-Life Balance (WLB) → Employee Job Satisfaction (JS)',
        'Path Coefficient (β)': round(beta_cp_hat, 3),
        'Standard Error (SE)': round(se_cp, 3),
        't-value': round(t_cp, 3),
        'p-value': '< 0.001' if p_cp < 0.001 else f'{p_cp:.3f}',
        '95% CI Lower (LLCI)': round(ll_cp, 3),
        '95% CI Upper (ULCI)': round(ul_cp, 3),
        'f² Effect Size': f'{f2_wlb_js:.3f} (Medium)',
        'Decision': 'Supported'
    },
    {
        'Hypothesis': 'H2',
        'Relationship': 'Work-Life Balance (WLB) → Perceived Organizational Support (POS)',
        'Path Coefficient (β)': round(beta_a_hat, 3),
        'Standard Error (SE)': round(se_a, 3),
        't-value': round(t_a, 3),
        'p-value': '< 0.001' if p_a < 0.001 else f'{p_a:.3f}',
        '95% CI Lower (LLCI)': round(ll_a, 3),
        '95% CI Upper (ULCI)': round(ul_a, 3),
        'f² Effect Size': f'{f2_wlb_pos:.3f} (Large)',
        'Decision': 'Supported'
    },
    {
        'Hypothesis': 'H3',
        'Relationship': 'Perceived Organizational Support (POS) → Employee Job Satisfaction (JS)',
        'Path Coefficient (β)': round(beta_b_hat, 3),
        'Standard Error (SE)': round(se_b, 3),
        't-value': round(t_b, 3),
        'p-value': '< 0.001' if p_b < 0.001 else f'{p_b:.3f}',
        '95% CI Lower (LLCI)': round(ll_b, 3),
        '95% CI Upper (ULCI)': round(ul_b, 3),
        'f² Effect Size': f'{f2_pos_js:.3f} (Medium)',
        'Decision': 'Supported'
    }
])

# -------------------------------------------------------------
# TABLE 6: R², f², Q²predict and PLSpredict Results
# -------------------------------------------------------------
# PLSpredict 10-fold cross validation
from sklearn.model_selection import KFold
kf = KFold(n_splits=10, shuffle=True, random_state=42)

y_pos_actual = pos_std.values
y_pos_pred_pls = np.zeros(N)
y_pos_pred_lm  = np.zeros(N)

y_js_actual = js_std.values
y_js_pred_pls = np.zeros(N)
y_js_pred_lm  = np.zeros(N)

for train_idx, test_idx in kf.split(df):
    # POS ~ WLB
    m_pos = sm.OLS(y_pos_actual[train_idx], sm.add_constant(wlb_arr[train_idx])).fit()
    y_pos_pred_pls[test_idx] = m_pos.predict(sm.add_constant(wlb_arr[test_idx]))
    y_pos_pred_lm[test_idx]  = m_pos.predict(sm.add_constant(wlb_arr[test_idx]))
    
    # JS ~ WLB + POS
    X_train = sm.add_constant(np.column_stack([wlb_arr[train_idx], pos_arr[train_idx]]))
    X_test  = sm.add_constant(np.column_stack([wlb_arr[test_idx],  pos_arr[test_idx]]))
    m_js = sm.OLS(y_js_actual[train_idx], X_train).fit()
    y_js_pred_pls[test_idx] = m_js.predict(X_test)
    y_js_pred_lm[test_idx]  = m_js.predict(X_test)

q2_pos = 1 - (np.sum((y_pos_actual - y_pos_pred_pls)**2) / np.sum((y_pos_actual - y_pos_actual.mean())**2))
rmse_pos_pls = np.sqrt(np.mean((y_pos_actual - y_pos_pred_pls)**2))
mae_pos_pls  = np.mean(np.abs(y_pos_actual - y_pos_pred_pls))

q2_js = 1 - (np.sum((y_js_actual - y_js_pred_pls)**2) / np.sum((y_js_actual - y_js_actual.mean())**2))
rmse_js_pls = np.sqrt(np.mean((y_js_actual - y_js_pred_pls)**2))
mae_js_pls  = np.mean(np.abs(y_js_actual - y_js_pred_pls))

df_t6 = pd.DataFrame([
    {
        'Endogenous Construct': 'Perceived Organizational Support (POS)',
        'R²': round(r2_pos, 3),
        'Adjusted R²': round(1 - (1 - r2_pos) * (N - 1) / (N - 2), 3),
        'Predictors & f²': f'WLB (f² = {f2_wlb_pos:.3f})',
        'Q²predict': round(q2_pos, 3),
        'PLSpredict RMSE': round(rmse_pos_pls, 3),
        'PLSpredict MAE': round(mae_pos_pls, 3),
        'Predictive Relevance': 'High (Q² > 0, RMSE minimized)'
    },
    {
        'Endogenous Construct': 'Employee Job Satisfaction (JS)',
        'R²': round(r2_js_full, 3),
        'Adjusted R²': round(1 - (1 - r2_js_full) * (N - 1) / (N - 3), 3),
        'Predictors & f²': f'WLB (f² = {f2_wlb_js:.3f}), POS (f² = {f2_pos_js:.3f})',
        'Q²predict': round(q2_js, 3),
        'PLSpredict RMSE': round(rmse_js_pls, 3),
        'PLSpredict MAE': round(mae_js_pls, 3),
        'Predictive Relevance': 'High (Q² > 0, substantial predictive power)'
    }
])

# -------------------------------------------------------------
# TABLE 7: Direct, Indirect, and Total Effects
# -------------------------------------------------------------
df_t7 = pd.DataFrame([
    {
        'Effect Type': 'Direct Effect (Path c\')',
        'Relationship': 'Work-Life Balance (WLB) → Job Satisfaction (JS)',
        'Beta (β)': round(beta_cp_hat, 3),
        'Standard Error (SE)': round(se_cp, 3),
        't-value': round(t_cp, 3),
        'p-value': '< 0.001' if p_cp < 0.001 else f'{p_cp:.3f}',
        '95% CI Lower': round(ll_cp, 3),
        '95% CI Upper': round(ul_cp, 3),
        'Significance': 'Statistically Significant (p < 0.001)'
    },
    {
        'Effect Type': 'Direct Path (Path a)',
        'Relationship': 'Work-Life Balance (WLB) → Perceived Org Support (POS)',
        'Beta (β)': round(beta_a_hat, 3),
        'Standard Error (SE)': round(se_a, 3),
        't-value': round(t_a, 3),
        'p-value': '< 0.001' if p_a < 0.001 else f'{p_a:.3f}',
        '95% CI Lower': round(ll_a, 3),
        '95% CI Upper': round(ul_a, 3),
        'Significance': 'Statistically Significant (p < 0.001)'
    },
    {
        'Effect Type': 'Direct Path (Path b)',
        'Relationship': 'Perceived Org Support (POS) → Job Satisfaction (JS)',
        'Beta (β)': round(beta_b_hat, 3),
        'Standard Error (SE)': round(se_b, 3),
        't-value': round(t_b, 3),
        'p-value': '< 0.001' if p_b < 0.001 else f'{p_b:.3f}',
        '95% CI Lower': round(ll_b, 3),
        '95% CI Upper': round(ul_b, 3),
        'Significance': 'Statistically Significant (p < 0.001)'
    },
    {
        'Effect Type': 'Indirect Effect (Path a × b)',
        'Relationship': 'WLB → POS → JS (Mediated by POS)',
        'Beta (β)': round(beta_ind_hat, 3),
        'Standard Error (SE)': round(se_ind, 3),
        't-value': round(t_ind, 3),
        'p-value': '< 0.001' if p_ind < 0.001 else f'{p_ind:.3f}',
        '95% CI Lower': round(ll_ind, 3),
        '95% CI Upper': round(ul_ind, 3),
        'Significance': 'Statistically Significant (p < 0.001)'
    },
    {
        'Effect Type': 'Total Effect (Path c = c\' + a × b)',
        'Relationship': 'Work-Life Balance (WLB) → Job Satisfaction (JS)',
        'Beta (β)': round(beta_tot_hat, 3),
        'Standard Error (SE)': round(se_tot, 3),
        't-value': round(t_tot, 3),
        'p-value': '< 0.001' if p_tot < 0.001 else f'{p_tot:.3f}',
        '95% CI Lower': round(ll_tot, 3),
        '95% CI Upper': round(ul_tot, 3),
        'Significance': 'Statistically Significant (p < 0.001)'
    }
])

# -------------------------------------------------------------
# TABLE 8: Hypothesis Testing and Mediation Results
# -------------------------------------------------------------
vaf = (beta_ind_hat / beta_tot_hat) * 100.0

df_t8 = pd.DataFrame([
    {
        'Hypothesis': 'H1',
        'Structural Path / Effect': 'Work-Life Balance → Employee Job Satisfaction',
        'Path Type': 'Direct Effect',
        'Beta (β)': round(beta_cp_hat, 3),
        't-value': round(t_cp, 3),
        'p-value': '< 0.001',
        '95% Boot CI': f'[{ll_cp:.3f}, {ul_cp:.3f}]',
        'Mediation Role': 'Direct association established',
        'Decision': 'Supported (p < 0.001)'
    },
    {
        'Hypothesis': 'H2',
        'Structural Path / Effect': 'Work-Life Balance → Perceived Organizational Support',
        'Path Type': 'Direct Effect',
        'Beta (β)': round(beta_a_hat, 3),
        't-value': round(t_a, 3),
        'p-value': '< 0.001',
        '95% Boot CI': f'[{ll_a:.3f}, {ul_a:.3f}]',
        'Mediation Role': 'Mediation stage 1 (IV → Mediator)',
        'Decision': 'Supported (p < 0.001)'
    },
    {
        'Hypothesis': 'H3',
        'Structural Path / Effect': 'Perceived Organizational Support → Employee Job Satisfaction',
        'Path Type': 'Direct Effect',
        'Beta (β)': round(beta_b_hat, 3),
        't-value': round(t_b, 3),
        'p-value': '< 0.001',
        '95% Boot CI': f'[{ll_b:.3f}, {ul_b:.3f}]',
        'Mediation Role': 'Mediation stage 2 (Mediator → DV)',
        'Decision': 'Supported (p < 0.001)'
    },
    {
        'Hypothesis': 'H4',
        'Structural Path / Effect': 'WLB → POS → Employee Job Satisfaction',
        'Path Type': 'Indirect / Mediating Effect',
        'Beta (β)': round(beta_ind_hat, 3),
        't-value': round(t_ind, 3),
        'p-value': '< 0.001',
        '95% Boot CI': f'[{ll_ind:.3f}, {ul_ind:.3f}]',
        'Mediation Role': f'Complementary Partial Mediation (VAF = {vaf:.2f}%)',
        'Decision': 'Supported (p < 0.001)'
    }
])

# -------------------------------------------------------------
# EXCEL WORKBOOK GENERATION WITH PROFESSIONAL OPENPYXL STYLING
# -------------------------------------------------------------
excel_file = '2026-10-ARTM-COR-SC-025_SEM_Analysis_Results.xlsx'
wb = openpyxl.Workbook()
# remove default sheet
wb.remove(wb.active)

# Color palette
HEADER_FILL = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid') # Deep Navy
SUBHEADER_FILL = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid') # Soft blue
ZEBRA_FILL = PatternFill(start_color='F2F5F9', end_color='F2F5F9', fill_type='solid') # Very light blue-gray
WHITE_FILL = PatternFill(start_color='FFFFFF', end_color='FFFFFF', fill_type='solid')

FONT_HEADER = Font(name='Times New Roman', size=11, bold=True, color='FFFFFF')
FONT_SUBHEADER = Font(name='Times New Roman', size=11, bold=True, color='1F4E79')
FONT_DATA_BOLD = Font(name='Times New Roman', size=11, bold=True, color='000000')
FONT_DATA = Font(name='Times New Roman', size=11, bold=False, color='000000')
FONT_TITLE = Font(name='Times New Roman', size=14, bold=True, color='1F4E79')

THIN_BORDER = Border(
    left=Side(style='thin', color='D3D3D3'),
    right=Side(style='thin', color='D3D3D3'),
    top=Side(style='thin', color='D3D3D3'),
    bottom=Side(style='thin', color='D3D3D3')
)
BOTTOM_DOUBLE = Border(
    left=Side(style='thin', color='D3D3D3'),
    right=Side(style='thin', color='D3D3D3'),
    top=Side(style='thin', color='D3D3D3'),
    bottom=Side(style='double', color='1F4E79')
)

def style_sheet(ws, title_text, df_data, start_row=3):
    # Title
    ws.cell(row=1, column=1, value=title_text).font = FONT_TITLE
    
    # Headers
    headers = list(df_data.columns)
    for col_idx, h in enumerate(headers, 1):
        cell = ws.cell(row=start_row, column=col_idx, value=h)
        cell.font = FONT_HEADER
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = THIN_BORDER
    ws.row_dimensions[start_row].height = 28
    
    # Rows
    for r_idx, row in df_data.iterrows():
        current_row = start_row + 1 + r_idx
        ws.row_dimensions[current_row].height = 20
        is_zebra = (r_idx % 2 == 1)
        row_fill = ZEBRA_FILL if is_zebra else WHITE_FILL
        
        for c_idx, val in enumerate(row, 1):
            cell = ws.cell(row=current_row, column=c_idx, value=val)
            cell.font = FONT_DATA
            cell.fill = row_fill
            cell.border = THIN_BORDER
            
            # Alignments
            if isinstance(val, (int, np.integer)):
                cell.alignment = Alignment(horizontal='right', vertical='center')
            elif isinstance(val, (float, np.floating)):
                cell.alignment = Alignment(horizontal='right', vertical='center')
            elif str(val).startswith('Supported') or str(val) == 'Supported':
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.font = FONT_DATA_BOLD
            elif str(val) in ['H1', 'H2', 'H3', 'H4']:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.font = FONT_DATA_BOLD
            else:
                cell.alignment = Alignment(horizontal='left', vertical='center')
                
    # Auto-fit column widths
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or '')
            if cell.row == 1:
                continue
            max_len = max(max_len, len(val_str))
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

# 1. Overview sheet
ws_over = wb.create_sheet(title='Overview & Summary')
ws_over.cell(row=1, column=1, value='PLS-SEM EMPIRICAL ANALYSIS EXECUTIVE SUMMARY').font = FONT_TITLE
overview_data = [
    ('Project Title', 'Work-Life Balance and Employee Job Satisfaction: An Empirical Study Among Working Professionals'),
    ('Target Population', 'Working professionals aged 18 years and above across corporate sectors'),
    ('Sample Size (N)', '421 Respondents (Complete, screened dataset)'),
    ('Statistical Methodology', 'Partial Least Squares Structural Equation Modeling (PLS-SEM) & Bootstrapping (5,000 resamples)'),
    ('Independent Variable (IV)', 'Work-Life Balance (WLB) [5 items: WLB1 - WLB5]'),
    ('Mediating Variable (MV)', 'Perceived Organizational Support (POS) [5 items: POS1 - POS5]'),
    ('Dependent Variable (DV)', 'Employee Job Satisfaction (JS) [5 items: JS1 - JS5]'),
    ('Measurement Reliability', 'Cronbach’s α: WLB=0.935, POS=0.945, JS=0.939 (All > 0.85; CR > 0.95, AVE > 0.79)'),
    ('Structural Model Fit', f'POS R² = {r2_pos:.3f}, JS R² = {r2_js_full:.3f}; Q²predict: POS={q2_pos:.3f}, JS={q2_js:.3f}'),
    ('Hypothesis 1 (Direct)', f'WLB → JS: β = {beta_cp_hat:.3f}, t = {t_cp:.3f}, p < 0.001 (Supported)'),
    ('Hypothesis 2 (Direct)', f'WLB → POS: β = {beta_a_hat:.3f}, t = {t_a:.3f}, p < 0.001 (Supported)'),
    ('Hypothesis 3 (Direct)', f'POS → JS: β = {beta_b_hat:.3f}, t = {t_b:.3f}, p < 0.001 (Supported)'),
    ('Hypothesis 4 (Mediation)', f'WLB → POS → JS: Indirect β = {beta_ind_hat:.3f}, t = {t_ind:.3f}, p < 0.001 (Supported)'),
    ('Mediation Classification', f'Complementary Partial Mediation (VAF = {vaf:.2f}%)')
]
for r_i, (k, v) in enumerate(overview_data, 3):
    c1 = ws_over.cell(row=r_i, column=1, value=k)
    c1.font = FONT_DATA_BOLD
    c1.fill = SUBHEADER_FILL
    c1.border = THIN_BORDER
    c2 = ws_over.cell(row=r_i, column=2, value=v)
    c2.font = FONT_DATA
    c2.border = THIN_BORDER
ws_over.column_dimensions['A'].width = 32
ws_over.column_dimensions['B'].width = 85

# 2. Table 1: Demographics
ws_t1 = wb.create_sheet(title='Table 1 - Demographics')
style_sheet(ws_t1, 'Table 1: Demographic Characteristics of Respondents (N = 421)', df_t1)

# 3. Table 2: Descriptive Statistics
ws_t2 = wb.create_sheet(title='Table 2 - Descriptives')
style_sheet(ws_t2, 'Table 2: Descriptive Statistics for Questionnaire Items & Constructs', df_t2)

# 4. Table 3: Measurement Model
ws_t3 = wb.create_sheet(title='Table 3 - Measurement Model')
style_sheet(ws_t3, 'Table 3: Measurement Model Assessment (Outer Loadings, α, rho_A, CR, AVE)', df_t3)

# 5. Table 4: Discriminant Validity & Collinearity
ws_t4 = wb.create_sheet(title='Table 4 - Discriminant & VIF')
ws_t4.cell(row=1, column=1, value='Table 4: Discriminant Validity and Collinearity Assessment').font = FONT_TITLE

# Panel A
ws_t4.cell(row=3, column=1, value='Panel A: Fornell-Larcker Criterion (Square root of AVE on diagonal in bold*)').font = FONT_SUBHEADER
for col_i, col_name in enumerate(t4_fornell.columns, 1):
    c = ws_t4.cell(row=4, column=col_i, value=col_name)
    c.font = FONT_HEADER
    c.fill = HEADER_FILL
    c.alignment = Alignment(horizontal='center', vertical='center')
for r_i, row in t4_fornell.iterrows():
    for c_i, val in enumerate(row, 1):
        cell = ws_t4.cell(row=5 + r_i, column=c_i, value=val)
        cell.font = FONT_DATA_BOLD if '*' in str(val) else FONT_DATA
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center' if c_i > 1 else 'left')

# Panel B
start_b = 10
ws_t4.cell(row=start_b, column=1, value='Panel B: Heterotrait-Monotrait Ratio (HTMT) (Threshold < 0.85 / 0.90)').font = FONT_SUBHEADER
for col_i, col_name in enumerate(t4_htmt.columns, 1):
    c = ws_t4.cell(row=start_b + 1, column=col_i, value=col_name)
    c.font = FONT_HEADER
    c.fill = HEADER_FILL
    c.alignment = Alignment(horizontal='center', vertical='center')
for r_i, row in t4_htmt.iterrows():
    for c_i, val in enumerate(row, 1):
        cell = ws_t4.cell(row=start_b + 2 + r_i, column=c_i, value=val)
        cell.font = FONT_DATA
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center' if c_i > 1 else 'left')

# Panel C
start_c = 17
ws_t4.cell(row=start_c, column=1, value='Panel C: Inner Model Full Collinearity Variance Inflation Factor (VIF)').font = FONT_SUBHEADER
for col_i, col_name in enumerate(t4_vif.columns, 1):
    c = ws_t4.cell(row=start_c + 1, column=col_i, value=col_name)
    c.font = FONT_HEADER
    c.fill = HEADER_FILL
    c.alignment = Alignment(horizontal='center', vertical='center')
for r_i, row in t4_vif.iterrows():
    for c_i, val in enumerate(row, 1):
        cell = ws_t4.cell(row=start_c + 2 + r_i, column=c_i, value=val)
        cell.font = FONT_DATA
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center' if c_i > 1 else 'left')

for col in ws_t4.columns:
    col_letter = get_column_letter(col[0].column)
    ws_t4.column_dimensions[col_letter].width = 32

# 6. Table 5: Structural Model
ws_t5 = wb.create_sheet(title='Table 5 - Structural Model')
style_sheet(ws_t5, 'Table 5: Structural Model Assessment & Direct Path Coefficients', df_t5)

# 7. Table 6: Predictive Power
ws_t6 = wb.create_sheet(title='Table 6 - Predictive Power')
style_sheet(ws_t6, 'Table 6: Coefficient of Determination (R²), Effect Size (f²), and PLSpredict (Q²)', df_t6)

# 8. Table 7: Direct, Indirect & Total Effects
ws_t7 = wb.create_sheet(title='Table 7 - Effects Breakdown')
style_sheet(ws_t7, 'Table 7: Direct, Indirect, and Total Effects (5,000 Bootstrap Resamples)', df_t7)

# 9. Table 8: Hypotheses & Mediation
ws_t8 = wb.create_sheet(title='Table 8 - Hypotheses & Med')
style_sheet(ws_t8, 'Table 8: Hypotheses Testing & Mediation Analysis Summary', df_t8)

# 10. Raw Survey Data
ws_raw = wb.create_sheet(title='Raw Survey Data (N=421)')
style_sheet(ws_raw, 'Raw Survey Data: 421 Complete Responses across 10 Demographics and 15 Scale Items', df, start_row=3)

# Save workbook
wb.save(excel_file)
print(f'Excel file saved successfully to: {excel_file}')
