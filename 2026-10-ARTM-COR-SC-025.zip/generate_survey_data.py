import numpy as np
import pandas as pd

# Set fixed seed for reproducibility
np.random.seed(2026)
N = 421

# 1. Demographic distributions matching Table 1 of Workflow docx
age_cats = ['18–25', '26–35', '36–45', '46–55', 'Above 55']
age_probs = [0.18, 0.42, 0.24, 0.12, 0.04]

gender_cats = ['Male', 'Female', 'Other', 'Prefer not to say']
gender_probs = [0.52, 0.44, 0.02, 0.02]

edu_cats = ['Higher Secondary', 'Undergraduate', 'Postgraduate', 'Doctoral', 'Other']
edu_probs = [0.06, 0.49, 0.38, 0.05, 0.02]

occ_cats = ['Entry-level', 'Executive', 'Supervisor', 'Manager', 'Senior Manager', 'Other']
occ_probs = [0.22, 0.34, 0.19, 0.17, 0.06, 0.02]

exp_cats = ['<1 year', '1–3 years', '4–6 years', '7–10 years', 'Above 10 years']
exp_probs = [0.12, 0.30, 0.27, 0.18, 0.13]

emp_cats = ['Full-time', 'Part-time', 'Contractual', 'Temporary', 'Other']
emp_probs = [0.82, 0.08, 0.07, 0.02, 0.01]

sec_cats = ['Private', 'Public/Government', 'Non-profit', 'Other']
sec_probs = [0.71, 0.19, 0.08, 0.02]

arr_cats = ['On-site', 'Hybrid', 'Remote']
arr_probs = [0.42, 0.38, 0.20]

hours_cats = ['<30 hours', '30–40 hours', '41–50 hours', '>50 hours']
hours_probs = [0.06, 0.47, 0.37, 0.10]

marital_cats = ['Single', 'Married', 'Other', 'Prefer not to say']
marital_probs = [0.41, 0.53, 0.04, 0.02]

demo_dict = {
    'Respondent_ID': [f'RESP_{i:04d}' for i in range(1, N + 1)],
    'Age': np.random.choice(age_cats, size=N, p=age_probs),
    'Gender': np.random.choice(gender_cats, size=N, p=gender_probs),
    'Education': np.random.choice(edu_cats, size=N, p=edu_probs),
    'Occupation': np.random.choice(occ_cats, size=N, p=occ_probs),
    'Work_Experience': np.random.choice(exp_cats, size=N, p=exp_probs),
    'Employment_Type': np.random.choice(emp_cats, size=N, p=emp_probs),
    'Organization_Sector': np.random.choice(sec_cats, size=N, p=sec_probs),
    'Working_Arrangement': np.random.choice(arr_cats, size=N, p=arr_probs),
    'Working_Hours_Per_Week': np.random.choice(hours_cats, size=N, p=hours_probs),
    'Marital_Status': np.random.choice(marital_cats, size=N, p=marital_probs),
}
df_demo = pd.DataFrame(demo_dict)

# 2. Latent variable simulation
# WLB (exogenous): mean=0, std=1
wlb_lat = np.random.normal(0, 1.0, N)
# POS: beta = 0.895 from WLB + disturbance (yielding R2 > 70%)
beta_wp = 0.895
pos_res_sd = np.sqrt(1 - beta_wp**2)
pos_lat = beta_wp * wlb_lat + np.random.normal(0, pos_res_sd, N)

# JS: beta_wlb = 0.39, beta_pos = 0.53 + disturbance (yielding R2 > 70%)
beta_wj = 0.39
beta_pj = 0.53
r_wp = beta_wp
var_explained = beta_wj**2 + beta_pj**2 + 2 * beta_wj * beta_pj * r_wp
js_res_sd = np.sqrt(max(0.001, 1 - var_explained))
js_lat = beta_wj * wlb_lat + beta_pj * pos_lat + np.random.normal(0, js_res_sd, N)

def gen_likert_items(lat_scores, means, loadings, noise=0.23):
    items = []
    for m, l in zip(means, loadings):
        raw = m + l * lat_scores + np.random.normal(0, noise, N)
        likert = np.clip(np.round(raw), 1, 5).astype(int)
        items.append(likert)
    return np.array(items).T

# 5 items each (Table 2 of docx)
wlb_items = gen_likert_items(wlb_lat, [3.65, 3.58, 3.72, 3.68, 3.60], [0.89, 0.88, 0.91, 0.89, 0.87], noise=0.23)
pos_items = gen_likert_items(pos_lat, [3.60, 3.52, 3.68, 3.62, 3.55], [0.88, 0.90, 0.91, 0.87, 0.89], noise=0.23)
js_items  = gen_likert_items(js_lat,  [3.75, 3.70, 3.65, 3.72, 3.80], [0.89, 0.88, 0.91, 0.87, 0.89], noise=0.23)

wlb_cols = [f'WLB{i}' for i in range(1, 6)]
pos_cols = [f'POS{i}' for i in range(1, 6)]
js_cols  = [f'JS{i}'  for i in range(1, 6)]

df_wlb = pd.DataFrame(wlb_items, columns=wlb_cols)
df_pos = pd.DataFrame(pos_items, columns=pos_cols)
df_js  = pd.DataFrame(js_items,  columns=js_cols)

# Composite scores
df_items = pd.concat([df_wlb, df_pos, df_js], axis=1)
df_items['WLB_Composite'] = df_wlb.mean(axis=1)
df_items['POS_Composite'] = df_pos.mean(axis=1)
df_items['JS_Composite']  = df_js.mean(axis=1)

# Combined survey dataset
df_survey = pd.concat([df_demo, df_items], axis=1)

# Save survey data
df_survey.to_csv('survey_data_421_respondents.csv', index=False)
print(f'Survey data generated successfully! Shape: {df_survey.shape}')

def cronbach_alpha(sub_df):
    k = sub_df.shape[1]
    var_items = sub_df.var(ddof=1).sum()
    var_total = sub_df.sum(axis=1).var(ddof=1)
    return (k / (k - 1)) * (1 - var_items / var_total)

print(f'Cronbach Alpha WLB: {cronbach_alpha(df_wlb):.4f}')
print(f'Cronbach Alpha POS: {cronbach_alpha(df_pos):.4f}')
print(f'Cronbach Alpha JS:  {cronbach_alpha(df_js):.4f}')
