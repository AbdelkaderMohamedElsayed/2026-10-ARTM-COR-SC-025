import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

# Set matplotlib parameters strictly per requirements
plt.rcParams["figure.figsize"] = (11, 7)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 18
plt.rcParams['font.weight'] = 'bold'

def generate_smartpls_diagram():
    fig, ax = plt.subplots(figsize=(11, 7), facecolor='#E2E6EA')
    ax.set_facecolor('#E2E6EA')
    ax.set_xlim(0, 11)
    ax.set_ylim(-0.3, 7.3)
    ax.axis('off')
    ax.grid(False)

    # Color palette faithfully replicating the SmartPLS canvas
    BG_CANVAS = '#E2E6EA'
    BLUE_CIRCLE = '#2A7EE8'        # Signature SmartPLS bright royal blue
    BLUE_CIRCLE_EDGE = '#185BC4'
    YELLOW_BOX = '#FFF176'         # Distinctive SmartPLS pastel yellow
    YELLOW_BOX_EDGE = '#D8C72B'
    TEAL_ERROR = '#9BC8C6'         # Pale teal/sage green error nodes
    TEAL_ERROR_EDGE = '#6F9D9B'
    TEAL_PIN = '#84B4B1'
    ARROW_COLOR = '#111111'
    TEXT_DARK = '#151515'

    r_circle = 0.58
    pos_wlb = np.array([2.5, 3.2])
    pos_pos = np.array([5.5, 4.5])
    pos_js  = np.array([8.5, 3.2])

    # -------------------------------------------------------------
    # 1. INNER STRUCTURAL PATHS
    # -------------------------------------------------------------
    # WLB -> POS (H2: 0.863)
    v_wp = pos_pos - pos_wlb
    u_wp = v_wp / np.linalg.norm(v_wp)
    p_start_wp = pos_wlb + u_wp * (r_circle + 0.03)
    p_end_wp = pos_pos - u_wp * (r_circle + 0.03)
    ax.annotate('', xy=p_end_wp, xytext=p_start_wp,
                arrowprops=dict(arrowstyle="-|>,head_width=0.35,head_length=0.45", color=ARROW_COLOR, lw=2.2))
    mid_wp = 0.5 * (p_start_wp + p_end_wp)
    ax.text(mid_wp[0] - 0.22, mid_wp[1] + 0.18, '0.863', ha='center', va='center',
            fontsize=13, fontweight='bold', color=TEXT_DARK,
            bbox=dict(boxstyle='square,pad=0.15', facecolor=BG_CANVAS, edgecolor='none'))

    # POS -> JS (H3: 0.474)
    v_pj = pos_js - pos_pos
    u_pj = v_pj / np.linalg.norm(v_pj)
    p_start_pj = pos_pos + u_pj * (r_circle + 0.03)
    p_end_pj = pos_js - u_pj * (r_circle + 0.03)
    ax.annotate('', xy=p_end_pj, xytext=p_start_pj,
                arrowprops=dict(arrowstyle="-|>,head_width=0.35,head_length=0.45", color=ARROW_COLOR, lw=2.2))
    mid_pj = 0.5 * (p_start_pj + p_end_pj)
    ax.text(mid_pj[0] + 0.22, mid_pj[1] + 0.18, '0.474', ha='center', va='center',
            fontsize=13, fontweight='bold', color=TEXT_DARK,
            bbox=dict(boxstyle='square,pad=0.15', facecolor=BG_CANVAS, edgecolor='none'))

    # Direct WLB -> JS (H1: 0.414)
    p_start_wj = np.array([pos_wlb[0] + r_circle + 0.03, pos_wlb[1]])
    p_end_wj = np.array([pos_js[0] - r_circle - 0.03, pos_js[1]])
    ax.annotate('', xy=p_end_wj, xytext=p_start_wj,
                arrowprops=dict(arrowstyle="-|>,head_width=0.35,head_length=0.45", color=ARROW_COLOR, lw=2.2))
    ax.text(5.5, 3.40, '0.414', ha='center', va='bottom',
            fontsize=13, fontweight='bold', color=TEXT_DARK,
            bbox=dict(boxstyle='square,pad=0.15', facecolor=BG_CANVAS, edgecolor='none'))

    # -------------------------------------------------------------
    # 2. LATENT CONSTRUCT CIRCLES & LABELS
    # -------------------------------------------------------------
    # WLB (Exogenous)
    c_wlb = plt.Circle(pos_wlb, r_circle, facecolor=BLUE_CIRCLE, edgecolor=BLUE_CIRCLE_EDGE, lw=1.8, zorder=5)
    ax.add_patch(c_wlb)
    ax.text(pos_wlb[0], pos_wlb[1] - r_circle - 0.25, 'WLB', ha='center', va='top', fontsize=17, fontweight='bold', color=TEXT_DARK)

    # POS (Endogenous, R2 = 0.744)
    c_pos = plt.Circle(pos_pos, r_circle, facecolor=BLUE_CIRCLE, edgecolor=BLUE_CIRCLE_EDGE, lw=1.8, zorder=5)
    ax.add_patch(c_pos)
    ax.text(pos_pos[0], pos_pos[1], '0.744', ha='center', va='center', fontsize=15, fontweight='bold', color='white', zorder=6)
    ax.text(pos_pos[0] + r_circle + 0.22, pos_pos[1] - 0.10, 'POS', ha='left', va='center', fontsize=17, fontweight='bold', color=TEXT_DARK)

    # POS Latent Error Term (Pinned to West-Northwest at 165 deg into wide open clear gap)
    angle_rad = np.radians(165)
    pin_start = pos_pos + np.array([np.cos(angle_rad), np.sin(angle_rad)]) * r_circle
    err_pos_xy = pin_start + np.array([np.cos(angle_rad), np.sin(angle_rad)]) * 0.55
    ax.plot([pin_start[0], err_pos_xy[0]], [pin_start[1], err_pos_xy[1]], color=TEAL_PIN, lw=1.4, zorder=4)
    ax.plot(pin_start[0], pin_start[1], marker='D', markersize=3.5, color=TEAL_PIN, zorder=4)
    c_err_pos = plt.Circle(err_pos_xy, 0.21, facecolor=TEAL_ERROR, edgecolor=TEAL_ERROR_EDGE, lw=1.2, zorder=7)
    ax.add_patch(c_err_pos)
    ax.text(err_pos_xy[0], err_pos_xy[1], '0.256', ha='center', va='center', fontsize=8.5, fontweight='bold', color=TEXT_DARK, zorder=8)

    # JS (Endogenous, R2 = 0.735)
    c_js = plt.Circle(pos_js, r_circle, facecolor=BLUE_CIRCLE, edgecolor=BLUE_CIRCLE_EDGE, lw=1.8, zorder=5)
    ax.add_patch(c_js)
    ax.text(pos_js[0], pos_js[1], '0.735', ha='center', va='center', fontsize=15, fontweight='bold', color='white', zorder=6)
    ax.text(pos_js[0], pos_js[1] - r_circle - 0.25, 'JS', ha='center', va='top', fontsize=17, fontweight='bold', color=TEXT_DARK)

    # JS Latent Error Term (Pinned straight up to 90 deg, identical to CUSL in sample image)
    err_js_xy = pos_js + np.array([0, r_circle + 0.45])
    ax.plot([pos_js[0], err_js_xy[0]], [pos_js[1] + r_circle, err_js_xy[1]], color=TEAL_PIN, lw=1.4, zorder=4)
    ax.plot(pos_js[0], pos_js[1] + r_circle, marker='D', markersize=3.5, color=TEAL_PIN, zorder=4)
    c_err_js = plt.Circle(err_js_xy, 0.21, facecolor=TEAL_ERROR, edgecolor=TEAL_ERROR_EDGE, lw=1.2, zorder=7)
    ax.add_patch(c_err_js)
    ax.text(err_js_xy[0], err_js_xy[1], '0.265', ha='center', va='center', fontsize=8.5, fontweight='bold', color=TEXT_DARK, zorder=8)

    # -------------------------------------------------------------
    # 3. INDICATOR BOXES, OUTER ARROWS, FACTOR LOADINGS & RESIDUALS
    # -------------------------------------------------------------
    box_w, box_h = 0.85, 0.35

    # --- WLB Indicators (Left side) ---
    wlb_loadings = [0.944, 0.945, 0.940, 0.928, 0.942]
    wlb_errors = [0.109, 0.107, 0.116, 0.139, 0.113]
    y_wlb_items = [5.2, 4.2, 3.2, 2.2, 1.2]
    x_wlb_items = 0.80

    for i in range(5):
        iy = y_wlb_items[i]
        ix = x_wlb_items
        l_val = wlb_loadings[i]
        e_val = wlb_errors[i]

        # Box
        rbox = patches.Rectangle((ix - box_w/2, iy - box_h/2), box_w, box_h,
                                 facecolor=YELLOW_BOX, edgecolor=YELLOW_BOX_EDGE, lw=1.3, zorder=4)
        ax.add_patch(rbox)
        ax.text(ix, iy, f'wlb_{i+1}', ha='center', va='center', fontsize=11, fontweight='bold', color=TEXT_DARK, zorder=5)

        # Arrow
        p_box_r = np.array([ix + box_w/2 + 0.02, iy])
        v_a = p_box_r - pos_wlb
        u_a = v_a / np.linalg.norm(v_a)
        p_circ = pos_wlb + u_a * r_circle

        ax.annotate('', xy=p_box_r, xytext=p_circ,
                    arrowprops=dict(arrowstyle="-|>,head_width=0.25,head_length=0.35", color=ARROW_COLOR, lw=1.3))

        # Loading with canvas background to prevent overlap
        p_mid = 0.52 * p_box_r + 0.48 * p_circ
        ax.text(p_mid[0], p_mid[1], f'{l_val:.3f}', ha='center', va='center',
                fontsize=9.5, fontweight='bold', color=TEXT_DARK,
                bbox=dict(boxstyle='square,pad=0.12', facecolor=BG_CANVAS, edgecolor='none'), zorder=6)

        # Error term (Left pin)
        err_x = ix - box_w/2 - 0.28
        ax.plot([ix - box_w/2, err_x + 0.14], [iy, iy], color=TEAL_PIN, lw=1.2, zorder=3)
        ax.plot(ix - box_w/2, iy, marker='D', markersize=3.0, color=TEAL_PIN, zorder=3)
        c_err = plt.Circle((err_x, iy), 0.14, facecolor=TEAL_ERROR, edgecolor=TEAL_ERROR_EDGE, lw=1.0, zorder=6)
        ax.add_patch(c_err)
        ax.text(err_x, iy, f'{e_val:.3f}', ha='center', va='center', fontsize=7.5, fontweight='bold', color=TEXT_DARK, zorder=7)

    # --- POS Indicators (Top side) ---
    pos_loadings = [0.945, 0.946, 0.951, 0.933, 0.946]
    pos_errors = [0.107, 0.105, 0.096, 0.130, 0.105]
    x_pos_items = [3.4, 4.4, 5.5, 6.6, 7.6]
    y_pos_items = 6.05

    for i in range(5):
        ix = x_pos_items[i]
        iy = y_pos_items
        l_val = pos_loadings[i]
        e_val = pos_errors[i]

        # Box
        rbox = patches.Rectangle((ix - box_w/2, iy - box_h/2), box_w, box_h,
                                 facecolor=YELLOW_BOX, edgecolor=YELLOW_BOX_EDGE, lw=1.3, zorder=4)
        ax.add_patch(rbox)
        ax.text(ix, iy, f'pos_{i+1}', ha='center', va='center', fontsize=11, fontweight='bold', color=TEXT_DARK, zorder=5)

        # Arrow
        p_box_b = np.array([ix, iy - box_h/2 - 0.02])
        v_a = p_box_b - pos_pos
        u_a = v_a / np.linalg.norm(v_a)
        p_circ = pos_pos + u_a * r_circle

        ax.annotate('', xy=p_box_b, xytext=p_circ,
                    arrowprops=dict(arrowstyle="-|>,head_width=0.25,head_length=0.35", color=ARROW_COLOR, lw=1.3))

        # Loading
        p_mid = 0.50 * p_box_b + 0.50 * p_circ
        ax.text(p_mid[0], p_mid[1], f'{l_val:.3f}', ha='center', va='center',
                fontsize=9.5, fontweight='bold', color=TEXT_DARK,
                bbox=dict(boxstyle='square,pad=0.12', facecolor=BG_CANVAS, edgecolor='none'), zorder=6)

        # Error term (Top pin)
        err_y = iy + box_h/2 + 0.28
        ax.plot([ix, ix], [iy + box_h/2, err_y - 0.14], color=TEAL_PIN, lw=1.2, zorder=3)
        ax.plot(ix, iy + box_h/2, marker='D', markersize=3.0, color=TEAL_PIN, zorder=3)
        c_err = plt.Circle((ix, err_y), 0.14, facecolor=TEAL_ERROR, edgecolor=TEAL_ERROR_EDGE, lw=1.0, zorder=6)
        ax.add_patch(c_err)
        ax.text(ix, err_y, f'{e_val:.3f}', ha='center', va='center', fontsize=7.5, fontweight='bold', color=TEXT_DARK, zorder=7)

    # --- JS Indicators (Right side) ---
    js_loadings = [0.943, 0.939, 0.945, 0.936, 0.931]
    js_errors = [0.111, 0.118, 0.107, 0.124, 0.133]
    y_js_items = [5.2, 4.2, 3.2, 2.2, 1.2]
    x_js_items = 10.20

    for i in range(5):
        iy = y_js_items[i]
        ix = x_js_items
        l_val = js_loadings[i]
        e_val = js_errors[i]

        # Box
        rbox = patches.Rectangle((ix - box_w/2, iy - box_h/2), box_w, box_h,
                                 facecolor=YELLOW_BOX, edgecolor=YELLOW_BOX_EDGE, lw=1.3, zorder=4)
        ax.add_patch(rbox)
        ax.text(ix, iy, f'js_{i+1}', ha='center', va='center', fontsize=11, fontweight='bold', color=TEXT_DARK, zorder=5)

        # Arrow
        p_box_l = np.array([ix - box_w/2 - 0.02, iy])
        v_a = p_box_l - pos_js
        u_a = v_a / np.linalg.norm(v_a)
        p_circ = pos_js + u_a * r_circle

        ax.annotate('', xy=p_box_l, xytext=p_circ,
                    arrowprops=dict(arrowstyle="-|>,head_width=0.25,head_length=0.35", color=ARROW_COLOR, lw=1.3))

        # Loading
        p_mid = 0.52 * p_box_l + 0.48 * p_circ
        ax.text(p_mid[0], p_mid[1], f'{l_val:.3f}', ha='center', va='center',
                fontsize=9.5, fontweight='bold', color=TEXT_DARK,
                bbox=dict(boxstyle='square,pad=0.12', facecolor=BG_CANVAS, edgecolor='none'), zorder=6)

        # Error term (Right pin)
        err_x = ix + box_w/2 + 0.28
        ax.plot([ix + box_w/2, err_x - 0.14], [iy, iy], color=TEAL_PIN, lw=1.2, zorder=3)
        ax.plot(ix + box_w/2, iy, marker='D', markersize=3.0, color=TEAL_PIN, zorder=3)
        c_err = plt.Circle((err_x, iy), 0.14, facecolor=TEAL_ERROR, edgecolor=TEAL_ERROR_EDGE, lw=1.0, zorder=6)
        ax.add_patch(c_err)
        ax.text(err_x, iy, f'{e_val:.3f}', ha='center', va='center', fontsize=7.5, fontweight='bold', color=TEXT_DARK, zorder=7)

    # Footnote note at the bottom
    ax.text(5.5, 0.10, 
            'SmartPLS Graphical Output: Circle values = R²; Path values = Standardized Beta (β); Arrow values = Factor Loadings (λ); Teal nodes = Error Variances.',
            ha='center', va='center', fontsize=10.5, style='italic', color='#333333')

    plt.tight_layout()
    plt.savefig('Figure_SmartPLS_SEM_Path_Diagram.png', dpi=800, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close()
    print('Figure_SmartPLS_SEM_Path_Diagram.png successfully updated at 800 DPI.')

if __name__ == '__main__':
    generate_smartpls_diagram()
