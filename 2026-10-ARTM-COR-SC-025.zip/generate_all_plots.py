import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.lines import Line2D

# User-specified styling rules:
# dpi=800, figsize=(11, 7), font.family='Times New Roman', font.size=18, font.weight='bold', remove grids
plt.rcParams['figure.figsize'] = (11, 7)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 18
plt.rcParams['font.weight'] = 'bold'

# Professional Academic Palette
NAVY = '#1B365D'
STEEL = '#2E6B9E'
GREEN = '#1E7E34'
DARK_GREEN = '#155724'
RED = '#B22222'
DARK_RED = '#781515'
GOLD = '#C27D00'
BG_BLUE = '#EDF4FA'
BG_GREEN = '#EAF5EC'
BG_RED = '#FBEAE8'
GRAY_TEXT = '#222222'

df = pd.read_csv('survey_data_421_respondents.csv')

# ==============================================================================
# FIGURE 1: RESEARCH METHODOLOGY WORKFLOW
# ==============================================================================
def plot_figure_1():
    fig, ax = plt.subplots(figsize=(11, 7))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 7)
    ax.axis('off')
    ax.grid(False)

    ax.text(6.0, 6.6, 'Figure 1: Research Methodology Workflow', 
            ha='center', va='center', fontsize=20, fontweight='bold', color=NAVY)

    steps = [
        ('1. Theoretical Foundation\n& Conceptualization', 'SET & OST Integration\nResearch Gap & Hypotheses', 2.0, 5.2),
        ('2. Questionnaire Design\n& Operationalization', '5-Point Likert Scale\n15 Validated Items', 6.0, 5.2),
        ('3. Sampling & Data\nCollection (N = 421)', 'Purposive Sampling\nWorking Professionals', 10.0, 5.2),
        ('4. Data Screening\n& Diagnostics', 'Missing Values, Outliers,\nNormality & CMB Check', 10.0, 3.4),
        ('5. Measurement Model\nEvaluation (PLS-SEM)', 'Outer Loadings, α > 0.85,\nCR, AVE, HTMT < 0.85', 6.0, 3.4),
        ('6. Structural Model\nAssessment', 'Collinearity VIF, β, R²,\nf² Effect Size, PLSpredict', 2.0, 3.4),
        ('7. Bootstrapping &\nHypothesis Testing', '5,000 Resamples, 95% CI,\nH1–H3 Direct Testing', 3.8, 1.4),
        ('8. Mediation Analysis\n& Theoretical Synthesis', 'H4: Complementary Partial\nMediation, VAF Calculation', 8.2, 1.4),
    ]

    for title, desc, x, y in steps:
        box = patches.FancyBboxPatch((x - 1.7, y - 0.65), 3.4, 1.3,
                                     boxstyle="round,pad=0.08,rounding_size=0.15",
                                     edgecolor=NAVY, facecolor='#EBF3FA', linewidth=2.0)
        ax.add_patch(box)
        ax.text(x, y + 0.18, title, ha='center', va='center', fontsize=11.5, fontweight='bold', color=NAVY)
        ax.text(x, y - 0.28, desc, ha='center', va='center', fontsize=10, fontweight='normal', color='#333333')

    arrow_props = dict(arrowstyle="->,head_width=0.35,head_length=0.45", color=NAVY, lw=2.5)
    
    # 1 -> 2 -> 3
    ax.annotate('', xy=(4.2, 5.2), xytext=(3.8, 5.2), arrowprops=arrow_props)
    ax.annotate('', xy=(8.2, 5.2), xytext=(7.8, 5.2), arrowprops=arrow_props)
    
    # 3 -> 4
    ax.annotate('', xy=(10.0, 4.15), xytext=(10.0, 4.45), arrowprops=arrow_props)
    
    # 4 -> 5 -> 6
    ax.annotate('', xy=(7.8, 3.4), xytext=(8.2, 3.4), arrowprops=arrow_props)
    ax.annotate('', xy=(3.8, 3.4), xytext=(4.2, 3.4), arrowprops=arrow_props)
    
    # 6 -> 7
    ax.annotate('', xy=(2.9, 2.15), xytext=(2.2, 2.65), arrowprops=arrow_props)
    
    # 7 -> 8
    ax.annotate('', xy=(6.4, 1.4), xytext=(5.6, 1.4), arrowprops=arrow_props)

    plt.tight_layout()
    plt.savefig('Figure_1_Research_Methodology_Workflow.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 1 regenerated cleanly.')

# ==============================================================================
# FIGURE 2: CONCEPTUAL FRAMEWORK
# ==============================================================================
def plot_figure_2():
    fig, ax = plt.subplots(figsize=(11, 7))
    ax.set_xlim(0, 11)
    ax.set_ylim(0, 7)
    ax.axis('off')
    ax.grid(False)

    ax.text(5.5, 6.6, 'Figure 2: Conceptual Framework', 
            ha='center', va='center', fontsize=20, fontweight='bold', color=NAVY)

    # IV: WLB
    iv_box = patches.FancyBboxPatch((0.6, 3.3), 2.9, 1.8,
                                    boxstyle="round,pad=0.1,rounding_size=0.2",
                                    edgecolor=NAVY, facecolor=BG_BLUE, linewidth=2.5)
    ax.add_patch(iv_box)
    ax.text(2.05, 4.5, 'Independent Variable', ha='center', va='center', fontsize=11, color='#555555')
    ax.text(2.05, 4.05, 'Work-Life\nBalance (WLB)', ha='center', va='center', fontsize=15, fontweight='bold', color=NAVY)
    ax.text(2.05, 3.55, '[5 Items: WLB1–WLB5]', ha='center', va='center', fontsize=10.5, color='#333333')

    # Mediator: POS
    med_box = patches.FancyBboxPatch((4.0, 4.7), 3.0, 1.7,
                                     boxstyle="round,pad=0.1,rounding_size=0.2",
                                     edgecolor=GREEN, facecolor=BG_GREEN, linewidth=2.5)
    ax.add_patch(med_box)
    ax.text(5.5, 5.85, 'Mediating Variable', ha='center', va='center', fontsize=11, color='#555555')
    ax.text(5.5, 5.4, 'Perceived Organizational\nSupport (POS)', ha='center', va='center', fontsize=14, fontweight='bold', color=GREEN)
    ax.text(5.5, 4.95, '[5 Items: POS1–POS5]', ha='center', va='center', fontsize=10.5, color='#333333')

    # DV: JS
    dv_box = patches.FancyBboxPatch((7.5, 3.3), 2.9, 1.8,
                                    boxstyle="round,pad=0.1,rounding_size=0.2",
                                    edgecolor=RED, facecolor=BG_RED, linewidth=2.5)
    ax.add_patch(dv_box)
    ax.text(8.95, 4.5, 'Dependent Variable', ha='center', va='center', fontsize=11, color='#555555')
    ax.text(8.95, 4.05, 'Employee Job\nSatisfaction (JS)', ha='center', va='center', fontsize=15, fontweight='bold', color=RED)
    ax.text(8.95, 3.55, '[5 Items: JS1–JS5]', ha='center', va='center', fontsize=10.5, color='#333333')

    # Path H2: WLB -> POS
    ax.annotate('', xy=(3.95, 5.3), xytext=(2.9, 4.8),
                arrowprops=dict(arrowstyle="->,head_width=0.4,head_length=0.5", color=NAVY, lw=2.5))
    ax.text(3.1, 5.35, 'H2 (+)', fontsize=13, fontweight='bold', color=NAVY,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', edgecolor=NAVY, lw=1.2))

    # Path H3: POS -> JS
    ax.annotate('', xy=(8.1, 4.8), xytext=(7.05, 5.3),
                arrowprops=dict(arrowstyle="->,head_width=0.4,head_length=0.5", color=NAVY, lw=2.5))
    ax.text(7.85, 5.35, 'H3 (+)', fontsize=13, fontweight='bold', color=NAVY,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', edgecolor=NAVY, lw=1.2))

    # Path H1: Direct WLB -> JS
    ax.annotate('', xy=(7.45, 3.9), xytext=(3.55, 3.9),
                arrowprops=dict(arrowstyle="->,head_width=0.4,head_length=0.5", color=NAVY, lw=2.5))
    ax.text(5.5, 3.9, 'H1 (+) Direct Path', ha='center', va='center', fontsize=13, fontweight='bold', color=NAVY,
            bbox=dict(boxstyle='round,pad=0.25', facecolor='white', edgecolor=NAVY, lw=1.2))

    # Path H4: Mediation label (neatly positioned between POS and direct path)
    ax.text(5.5, 4.35, 'H4: Mediation Mechanism (WLB → POS → JS)', ha='center', va='center',
            fontsize=12, fontweight='bold', color=DARK_GREEN,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='#E8F5E9', edgecolor=GREEN, lw=1.2))

    # Control Variables Box at the bottom
    ctrl_box = patches.FancyBboxPatch((1.5, 0.4), 8.0, 1.6,
                                      boxstyle="round,pad=0.1,rounding_size=0.2",
                                      edgecolor='#7F8C8D', facecolor='#F8F9FA', linewidth=1.8, linestyle='--')
    ax.add_patch(ctrl_box)
    ax.text(5.5, 1.65, 'Control Variables Included in Structural Model', ha='center', va='center',
            fontsize=12.5, fontweight='bold', color='#333333')
    ax.text(5.5, 1.15, 'Age • Gender • Education • Job Position • Work Experience\nWeekly Working Hours • Work Arrangement • Organization Sector',
            ha='center', va='center', fontsize=11, fontweight='normal', color='#555555')

    # Clean control arrows from left and right corners of control box to WLB and JS
    ax.annotate('', xy=(2.0, 3.25), xytext=(2.5, 2.05),
                arrowprops=dict(arrowstyle="->,head_width=0.25,head_length=0.35", color='#7F8C8D', lw=1.5, linestyle=':'))
    ax.annotate('', xy=(8.9, 3.25), xytext=(8.4, 2.05),
                arrowprops=dict(arrowstyle="->,head_width=0.25,head_length=0.35", color='#7F8C8D', lw=1.5, linestyle=':'))

    plt.tight_layout()
    plt.savefig('Figure_2_Conceptual_Framework.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 2 regenerated cleanly.')

# ==============================================================================
# FIGURE 3: PLS-SEM MEASUREMENT MODEL (ZERO OVERLAP DESIGN)
# ==============================================================================
def plot_figure_3():
    fig, ax = plt.subplots(figsize=(11, 7))
    ax.set_xlim(0, 11)
    ax.set_ylim(0, 7)
    ax.axis('off')
    ax.grid(False)

    ax.text(5.5, 6.65, 'Figure 3: PLS-SEM Measurement Model', 
            ha='center', va='center', fontsize=20, fontweight='bold', color=NAVY)

    # Construct Boxes
    # WLB at (1.5, 2.5), POS at (4.35, 3.5), JS at (7.2, 2.5)
    wlb_box = patches.FancyBboxPatch((1.5, 2.5), 2.3, 1.7,
                                     boxstyle="round,pad=0.08,rounding_size=0.22",
                                     edgecolor=NAVY, facecolor=BG_BLUE, linewidth=2.2)
    ax.add_patch(wlb_box)
    ax.text(2.65, 3.65, 'Work-Life Balance\n(WLB)', ha='center', va='center', fontsize=12.5, fontweight='bold', color=NAVY)
    ax.text(2.65, 2.95, 'α = 0.967 | CR = 0.974\nAVE = 0.883', ha='center', va='center', fontsize=10.5, color='#333333')

    pos_box = patches.FancyBboxPatch((4.35, 3.5), 2.3, 1.7,
                                     boxstyle="round,pad=0.08,rounding_size=0.22",
                                     edgecolor=GREEN, facecolor=BG_GREEN, linewidth=2.2)
    ax.add_patch(pos_box)
    ax.text(5.5, 4.65, 'Perceived Org.\nSupport (POS)', ha='center', va='center', fontsize=12.5, fontweight='bold', color=GREEN)
    ax.text(5.5, 3.95, 'α = 0.969 | CR = 0.976\nAVE = 0.891', ha='center', va='center', fontsize=10.5, color='#333333')

    js_box = patches.FancyBboxPatch((7.2, 2.5), 2.3, 1.7,
                                    boxstyle="round,pad=0.08,rounding_size=0.22",
                                    edgecolor=RED, facecolor=BG_RED, linewidth=2.2)
    ax.add_patch(js_box)
    ax.text(8.35, 3.65, 'Job Satisfaction\n(JS)', ha='center', va='center', fontsize=12.5, fontweight='bold', color=RED)
    ax.text(8.35, 2.95, 'α = 0.966 | CR = 0.974\nAVE = 0.881', ha='center', va='center', fontsize=10.5, color='#333333')

    # WLB Items on left: x = 0.15 to 0.95
    wlb_loadings = [0.944, 0.945, 0.940, 0.928, 0.942]
    for i, l in enumerate(wlb_loadings):
        iy = 5.0 - i * 0.70
        ibox = patches.FancyBboxPatch((0.15, iy - 0.22), 0.85, 0.44,
                                      boxstyle="round,pad=0.04,rounding_size=0.08",
                                      edgecolor=NAVY, facecolor='white', linewidth=1.5)
        ax.add_patch(ibox)
        ax.text(0.575, iy + 0.08, f'WLB{i+1}', ha='center', va='center', fontsize=9.5, fontweight='bold', color=NAVY)
        ax.text(0.575, iy - 0.10, f'λ={l:.3f}', ha='center', va='center', fontsize=8.5, fontweight='bold', color='#444444')
        
        # Line from item right edge (1.00) to construct left edge (1.50)
        ax.annotate('', xy=(1.48, 3.35), xytext=(1.02, iy),
                    arrowprops=dict(arrowstyle="->,head_width=0.2,head_length=0.3", color=NAVY, lw=1.3))

    # POS Items on top: iy = 6.25 (ample clearance above POS box top at 5.20)
    pos_loadings = [0.945, 0.946, 0.951, 0.933, 0.946]
    for i, l in enumerate(pos_loadings):
        ix = 3.55 + i * 0.98
        iy = 6.25
        ibox = patches.FancyBboxPatch((ix - 0.40, iy - 0.22), 0.80, 0.44,
                                      boxstyle="round,pad=0.04,rounding_size=0.08",
                                      edgecolor=GREEN, facecolor='white', linewidth=1.5)
        ax.add_patch(ibox)
        ax.text(ix, iy + 0.08, f'POS{i+1}', ha='center', va='center', fontsize=9.5, fontweight='bold', color=GREEN)
        ax.text(ix, iy - 0.10, f'λ={l:.3f}', ha='center', va='center', fontsize=8.5, fontweight='bold', color='#444444')
        
        # Line from item bottom (6.03) to POS box top (5.22)
        ax.annotate('', xy=(ix, 5.22), xytext=(ix, 6.01),
                    arrowprops=dict(arrowstyle="->,head_width=0.2,head_length=0.25", color=GREEN, lw=1.3))

    # JS Items on far right: x = 10.0 to 10.85
    js_loadings = [0.943, 0.939, 0.945, 0.936, 0.931]
    for i, l in enumerate(js_loadings):
        iy = 5.0 - i * 0.70
        ibox = patches.FancyBboxPatch((10.0, iy - 0.22), 0.85, 0.44,
                                      boxstyle="round,pad=0.04,rounding_size=0.08",
                                      edgecolor=RED, facecolor='white', linewidth=1.5)
        ax.add_patch(ibox)
        ax.text(10.425, iy + 0.08, f'JS{i+1}', ha='center', va='center', fontsize=9.5, fontweight='bold', color=RED)
        ax.text(10.425, iy - 0.10, f'λ={l:.3f}', ha='center', va='center', fontsize=8.5, fontweight='bold', color='#444444')
        
        # Line from JS box right edge (9.50) to item left edge (10.0)
        ax.annotate('', xy=(9.98, iy), xytext=(9.52, 3.35),
                    arrowprops=dict(arrowstyle="->,head_width=0.2,head_length=0.3", color=RED, lw=1.3))

    # Inter-construct correlation curved arrows with clean badges
    ax.annotate('', xy=(4.30, 4.10), xytext=(3.85, 3.85),
                arrowprops=dict(arrowstyle="<->,head_width=0.3,head_length=0.35", color=NAVY, lw=1.8))
    ax.text(4.07, 4.15, 'r = 0.863', ha='center', va='center', fontsize=10.5, fontweight='bold', color=NAVY,
            bbox=dict(boxstyle='round,pad=0.15', facecolor='white', edgecolor=NAVY, lw=1.0))

    ax.annotate('', xy=(7.15, 3.85), xytext=(6.70, 4.10),
                arrowprops=dict(arrowstyle="<->,head_width=0.3,head_length=0.35", color=RED, lw=1.8))
    ax.text(6.93, 4.15, 'r = 0.831', ha='center', va='center', fontsize=10.5, fontweight='bold', color=RED,
            bbox=dict(boxstyle='round,pad=0.15', facecolor='white', edgecolor=RED, lw=1.0))

    ax.annotate('', xy=(7.15, 2.85), xytext=(3.85, 2.85),
                arrowprops=dict(arrowstyle="<->,head_width=0.3,head_length=0.35", color='#333333', lw=1.8))
    ax.text(5.5, 2.85, 'r = 0.823', ha='center', va='center', fontsize=11, fontweight='bold', color='#333333',
            bbox=dict(boxstyle='round,pad=0.18', facecolor='white', edgecolor='#555555', lw=1.0))

    # Measurement Model Quality Summary Box at Bottom
    sum_box = patches.FancyBboxPatch((1.0, 0.30), 9.0, 1.25,
                                     boxstyle="round,pad=0.08,rounding_size=0.15",
                                     edgecolor='#CCCCCC', facecolor='#F8F9FA', linewidth=1.5)
    ax.add_patch(sum_box)
    ax.text(5.5, 1.25, 'Measurement Model Assessment Benchmarks (All Criteria Satisfied)', 
            ha='center', va='center', fontsize=12, fontweight='bold', color=NAVY)
    ax.text(5.5, 0.90, '• Indicator Reliability: All 15 outer loadings λ ≥ 0.928 (Threshold ≥ 0.708)\n• Internal Consistency: Cronbach’s α ≥ 0.966 (Threshold ≥ 0.85) | Composite Reliability (CR) ≥ 0.974 (Threshold ≥ 0.70)',
            ha='center', va='center', fontsize=10, fontweight='normal', color='#222222')
    ax.text(5.5, 0.52, '• Convergent Validity: Average Variance Extracted (AVE) ≥ 0.881 (Threshold ≥ 0.50) across all constructs',
            ha='center', va='center', fontsize=10, fontweight='normal', color='#222222')

    plt.tight_layout()
    plt.savefig('Figure_3_PLS_SEM_Measurement_Model.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 3 regenerated cleanly.')

# ==============================================================================
# FIGURE 4: PLS-SEM STRUCTURAL MODEL (CLEAN NO OVERLAP)
# ==============================================================================
def plot_figure_4():
    fig, ax = plt.subplots(figsize=(11, 7))
    ax.set_xlim(0, 11)
    ax.set_ylim(0, 7)
    ax.axis('off')
    ax.grid(False)

    ax.text(5.5, 6.6, 'Figure 4: PLS-SEM Structural Model Results', 
            ha='center', va='center', fontsize=20, fontweight='bold', color=NAVY)

    # Exogenous WLB Box (width 2.6, x: 0.5 to 3.1)
    wlb_box = patches.FancyBboxPatch((0.5, 2.9), 2.6, 1.8,
                                     boxstyle="round,pad=0.1,rounding_size=0.25",
                                     edgecolor=NAVY, facecolor=BG_BLUE, linewidth=2.5)
    ax.add_patch(wlb_box)
    ax.text(1.8, 4.2, 'Exogenous Construct', ha='center', va='center', fontsize=11, color='#555555')
    ax.text(1.8, 3.75, 'Work-Life\nBalance (WLB)', ha='center', va='center', fontsize=15, fontweight='bold', color=NAVY)
    ax.text(1.8, 3.2, '[Exogenous Predictor]', ha='center', va='center', fontsize=10, color='#444444')

    # Mediator POS Box (width 2.6, x: 4.2 to 6.8)
    pos_box = patches.FancyBboxPatch((4.2, 4.6), 2.6, 1.7,
                                     boxstyle="round,pad=0.1,rounding_size=0.25",
                                     edgecolor=GREEN, facecolor=BG_GREEN, linewidth=2.5)
    ax.add_patch(pos_box)
    ax.text(5.5, 5.85, 'Endogenous Mediator', ha='center', va='center', fontsize=11, color='#555555')
    ax.text(5.5, 5.4, 'Perceived Org.\nSupport (POS)', ha='center', va='center', fontsize=15, fontweight='bold', color=GREEN)
    ax.text(5.5, 4.88, 'R² = 0.744 | Q² = 0.742', ha='center', va='center', fontsize=11.5, fontweight='bold', color=DARK_GREEN,
            bbox=dict(boxstyle='round,pad=0.18', facecolor='white', edgecolor=GREEN, lw=1.2))

    # Outcome JS Box (width 2.6, x: 7.9 to 10.5)
    js_box = patches.FancyBboxPatch((7.9, 2.9), 2.6, 1.8,
                                    boxstyle="round,pad=0.1,rounding_size=0.25",
                                    edgecolor=RED, facecolor=BG_RED, linewidth=2.5)
    ax.add_patch(js_box)
    ax.text(9.2, 4.2, 'Endogenous Outcome', ha='center', va='center', fontsize=11, color='#555555')
    ax.text(9.2, 3.75, 'Job Satisfaction\n(JS)', ha='center', va='center', fontsize=15, fontweight='bold', color=RED)
    ax.text(9.2, 3.2, 'R² = 0.735 | Q² = 0.731', ha='center', va='center', fontsize=11.5, fontweight='bold', color=DARK_RED,
            bbox=dict(boxstyle='round,pad=0.18', facecolor='white', edgecolor=RED, lw=1.2))

    # Path H2: WLB -> POS
    ax.annotate('', xy=(4.15, 5.2), xytext=(2.7, 4.65),
                arrowprops=dict(arrowstyle="->,head_width=0.4,head_length=0.5", color=NAVY, lw=2.8))
    ax.text(2.65, 5.45, 'H2: β = 0.863***\nt = 65.66 | p < 0.001\nf² = 2.910 (Large)', 
            fontsize=10.5, fontweight='bold', color=NAVY,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', edgecolor=NAVY, lw=1.3))

    # Path H3: POS -> JS
    ax.annotate('', xy=(8.3, 4.65), xytext=(6.85, 5.2),
                arrowprops=dict(arrowstyle="->,head_width=0.4,head_length=0.5", color=NAVY, lw=2.8))
    ax.text(8.35, 5.45, 'H3: β = 0.474***\nt = 9.12 | p < 0.001\nf² = 0.217 (Medium)', 
            fontsize=10.5, fontweight='bold', color=NAVY,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', edgecolor=NAVY, lw=1.3))

    # Path H1: Direct WLB -> JS (Generous gap between 3.1 and 7.9)
    ax.annotate('', xy=(7.85, 3.7), xytext=(3.15, 3.7),
                arrowprops=dict(arrowstyle="->,head_width=0.4,head_length=0.5", color=NAVY, lw=2.8))
    ax.text(5.5, 3.7, 'H1: Direct β = 0.414***\nt = 7.76 | p < 0.001 | f² = 0.165', 
            ha='center', va='center', fontsize=11, fontweight='bold', color=NAVY,
            bbox=dict(boxstyle='round,pad=0.22', facecolor='white', edgecolor=NAVY, lw=1.3))

    # Mediation & Structural Findings Box at Bottom
    res_box = patches.FancyBboxPatch((0.5, 0.35), 10.0, 1.8,
                                     boxstyle="round,pad=0.1,rounding_size=0.2",
                                     edgecolor=GREEN, facecolor='#F3F9F4', linewidth=2.0)
    ax.add_patch(res_box)
    ax.text(5.5, 1.82, 'Summary of Hypotheses Testing & Mediation Analysis (5,000 Bootstrap Resamples)', 
            ha='center', va='center', fontsize=12.5, fontweight='bold', color=DARK_GREEN)
    ax.text(5.5, 1.32, '• H1 (Direct WLB → JS): β = 0.414, t = 7.76, p < 0.001, 95% CI [0.308, 0.517] → Supported\n• H2 (WLB → POS): β = 0.863, t = 65.66, p < 0.001, 95% CI [0.835, 0.886] → Supported\n• H3 (POS → JS): β = 0.474, t = 9.12, p < 0.001, 95% CI [0.372, 0.576] → Supported',
            ha='center', va='center', fontsize=10.5, fontweight='normal', color='#222222')
    ax.text(5.5, 0.70, '• H4 (Indirect Mediation WLB → POS → JS): β = 0.409, t = 8.92, p < 0.001, 95% CI [0.319, 0.500] → Supported\nMediation Type: Complementary Partial Mediation (VAF = 49.69%, Total Effect β = 0.823, t = 47.16)',
            ha='center', va='center', fontsize=10.5, fontweight='bold', color=DARK_RED)

    plt.tight_layout()
    plt.savefig('Figure_4_PLS_SEM_Structural_Model.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 4 regenerated cleanly.')

# ==============================================================================
# FIGURE 5: MEDIATION EFFECT (CLEAN NO OVERLAP)
# ==============================================================================
def plot_figure_5():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7), gridspec_kw={'width_ratios': [1.15, 0.85]})
    
    # Subplot 1: Path Diagram
    ax1.set_xlim(0, 10)
    ax1.set_ylim(0, 10)
    ax1.axis('off')
    ax1.grid(False)

    ax1.text(5.0, 9.5, '(A) Mediation Path Decomposition', 
             ha='center', va='center', fontsize=15, fontweight='bold', color=NAVY)

    # Nodes
    b1 = patches.FancyBboxPatch((0.4, 2.5), 2.7, 1.8, boxstyle="round,pad=0.08,rounding_size=0.2",
                                edgecolor=NAVY, facecolor=BG_BLUE, lw=2.2)
    ax1.add_patch(b1)
    ax1.text(1.75, 3.4, 'Work-Life\nBalance\n(WLB)', ha='center', va='center', fontsize=12.5, fontweight='bold', color=NAVY)

    b2 = patches.FancyBboxPatch((3.65, 6.6), 2.7, 1.7, boxstyle="round,pad=0.08,rounding_size=0.2",
                                edgecolor=GREEN, facecolor=BG_GREEN, lw=2.2)
    ax1.add_patch(b2)
    ax1.text(5.0, 7.45, 'Mediator\n(POS)', ha='center', va='center', fontsize=13, fontweight='bold', color=GREEN)

    b3 = patches.FancyBboxPatch((6.9, 2.5), 2.7, 1.8, boxstyle="round,pad=0.08,rounding_size=0.2",
                                edgecolor=RED, facecolor=BG_RED, lw=2.2)
    ax1.add_patch(b3)
    ax1.text(8.25, 3.4, 'Job\nSatisfaction\n(JS)', ha='center', va='center', fontsize=12.5, fontweight='bold', color=RED)

    # Path a
    ax1.annotate('', xy=(3.6, 6.8), xytext=(2.4, 4.4),
                 arrowprops=dict(arrowstyle="->,head_width=0.35,head_length=0.45", color=NAVY, lw=2.5))
    ax1.text(2.0, 5.8, 'Path a: 0.863***\nt = 65.66', fontsize=10.5, fontweight='bold', color=NAVY,
             bbox=dict(boxstyle='round,pad=0.15', facecolor='white', edgecolor=NAVY, lw=1))

    # Path b
    ax1.annotate('', xy=(7.6, 4.4), xytext=(6.4, 6.8),
                 arrowprops=dict(arrowstyle="->,head_width=0.35,head_length=0.45", color=NAVY, lw=2.5))
    ax1.text(8.0, 5.8, 'Path b: 0.474***\nt = 9.12', fontsize=10.5, fontweight='bold', color=NAVY,
             bbox=dict(boxstyle='round,pad=0.15', facecolor='white', edgecolor=NAVY, lw=1))

    # Path c' (Direct)
    ax1.annotate('', xy=(6.8, 3.4), xytext=(3.2, 3.4),
                 arrowprops=dict(arrowstyle="->,head_width=0.35,head_length=0.45", color=NAVY, lw=2.5))
    ax1.text(5.0, 3.85, "Direct Effect (c'): β = 0.414*** (t = 7.76)", ha='center', va='center',
             fontsize=10.5, fontweight='bold', color=NAVY,
             bbox=dict(boxstyle='round,pad=0.18', facecolor='white', edgecolor=NAVY, lw=1))

    # Summary callout
    ax1.text(5.0, 1.1, 'Total Effect (c = c\' + a×b) = 0.823*** (t = 47.16)\nIndirect Effect (a×b) = 0.409*** (t = 8.92)\nVAF = 49.69% (Complementary Partial Mediation)',
             ha='center', va='center', fontsize=10, fontweight='bold', color='#222222',
             bbox=dict(boxstyle='round,pad=0.22', facecolor='#F8F9FA', edgecolor='#CCCCCC', lw=1.2))

    # Subplot 2: Bar Chart with CI
    ax2.grid(False)
    effects = ['Direct (c\')', 'Indirect (a×b)', 'Total (c)']
    betas = [0.414, 0.409, 0.823]
    ci_low = [0.308, 0.319, 0.786]
    ci_high = [0.517, 0.500, 0.854]
    y_err = [
        [b - cl for b, cl in zip(betas, ci_low)],
        [ch - b for b, ch in zip(betas, ci_high)]
    ]

    colors = [STEEL, GREEN, GOLD]
    bars = ax2.bar(effects, betas, yerr=y_err, capsize=8, color=colors, edgecolor='black', lw=1.8, width=0.52)

    ax2.set_ylabel('Standardized Effect (β)', fontsize=14, fontweight='bold')
    ax2.set_ylim(0, 1.05)
    ax2.set_title('(B) Effect Sizes & 95% CIs', fontsize=15, fontweight='bold', color=NAVY, pad=15)

    for bar, val in zip(bars, betas):
        y = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2, y + 0.09, f'{val:.3f}***', 
                 ha='center', va='bottom', fontsize=11, fontweight='bold', color='#111111')

    fig.suptitle('Figure 5: Mediation Effect of Perceived Organizational Support', 
                 fontsize=20, fontweight='bold', color=NAVY, y=0.98)

    plt.tight_layout()
    plt.savefig('Figure_5_Mediation_Effect_of_POS.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 5 regenerated cleanly.')

# ==============================================================================
# FIGURE 6: INDICATOR OUTER LOADINGS (CLEAN LEGEND PLACEMENT)
# ==============================================================================
def plot_figure_6():
    fig, ax = plt.subplots(figsize=(11, 7))
    ax.grid(False)

    indicators = [
        'WLB1', 'WLB2', 'WLB3', 'WLB4', 'WLB5',
        'POS1', 'POS2', 'POS3', 'POS4', 'POS5',
        'JS1', 'JS2', 'JS3', 'JS4', 'JS5'
    ]
    loadings = [
        0.944, 0.945, 0.940, 0.928, 0.942,
        0.945, 0.946, 0.951, 0.933, 0.946,
        0.943, 0.939, 0.945, 0.936, 0.931
    ]
    colors = [STEEL]*5 + [GREEN]*5 + [RED]*5

    y_pos = np.arange(len(indicators))
    bars = ax.barh(y_pos, loadings, color=colors, edgecolor='black', lw=1.4, height=0.62)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(indicators, fontsize=12, fontweight='bold')
    ax.invert_yaxis()

    ax.axvline(0.708, color='crimson', linestyle='--', linewidth=2.5)
    ax.set_xlim(0, 1.15)
    ax.set_xlabel('Outer Loading (λ)', fontsize=15, fontweight='bold')
    ax.set_title('Figure 6: Indicator Outer Loadings Across Constructs', fontsize=20, fontweight='bold', color=NAVY, pad=15)

    for bar, val in zip(bars, loadings):
        ax.text(val + 0.015, bar.get_y() + bar.get_height()/2, f'{val:.3f}', 
                va='center', fontsize=11, fontweight='bold', color='#222222')

    # Legend placed at lower left with zero overlap
    legend_elements = [
        patches.Patch(facecolor=STEEL, edgecolor='black', label='Work-Life Balance (WLB)'),
        patches.Patch(facecolor=GREEN, edgecolor='black', label='Perceived Org. Support (POS)'),
        patches.Patch(facecolor=RED, edgecolor='black', label='Job Satisfaction (JS)'),
        Line2D([0], [0], color='crimson', lw=2.5, linestyle='--', label='Threshold λ ≥ 0.708')
    ]
    ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(0.02, 0.02),
              fontsize=10.5, frameon=True, facecolor='#FAFAFA', edgecolor='#CCCCCC')

    plt.tight_layout()
    plt.savefig('Figure_6_Indicator_Outer_Loadings.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 6 regenerated cleanly.')

# ==============================================================================
# FIGURE 7: DISCRIMINANT VALIDITY HEATMAP (SINGLE CLEAN ANNOTATION)
# ==============================================================================
def plot_figure_7():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))
    ax1.grid(False)
    ax2.grid(False)

    labels = ['WLB', 'POS', 'JS']

    # Panel A: Fornell-Larcker
    fl_matrix = np.array([
        [0.940, np.nan, np.nan],
        [0.863, 0.944, np.nan],
        [0.823, 0.831, 0.939]
    ])
    mask1 = np.isnan(fl_matrix)
    sns.heatmap(fl_matrix, mask=mask1, annot=False, cmap='Blues', cbar=False,
                xticklabels=labels, yticklabels=labels, ax=ax1,
                linewidths=2.0, linecolor='white')
    ax1.set_title('(A) Fornell-Larcker Criterion\n(Diagonal: √AVE in bold*)', fontsize=15, fontweight='bold', color=NAVY, pad=12)

    # Clean manual text drawing for Panel A
    for i in range(3):
        for j in range(i + 1):
            val = fl_matrix[i, j]
            if i == j:
                ax1.text(j + 0.5, i + 0.5, f'{val:.3f}*\n(√AVE)', ha='center', va='center',
                         fontsize=13, fontweight='bold', color='white')
            else:
                ax1.text(j + 0.5, i + 0.5, f'{val:.3f}', ha='center', va='center',
                         fontsize=13, fontweight='bold', color='#1B365D')

    # Panel B: HTMT
    htmt_matrix = np.array([
        [np.nan, np.nan, np.nan],
        [0.891, np.nan, np.nan],
        [0.851, 0.859, np.nan]
    ])
    mask2 = np.isnan(htmt_matrix)
    sns.heatmap(htmt_matrix, mask=mask2, annot=False, cmap='Greens', cbar=False,
                xticklabels=labels, yticklabels=labels, ax=ax2,
                linewidths=2.0, linecolor='white')
    ax2.set_title('(B) HTMT Ratio\n(Threshold < 0.90 / 0.85)', fontsize=15, fontweight='bold', color=NAVY, pad=12)

    # Clean manual text drawing for Panel B
    for i in range(1, 3):
        for j in range(i):
            val = htmt_matrix[i, j]
            ax2.text(j + 0.5, i + 0.5, f'{val:.3f}\n(< 0.90 Valid)', ha='center', va='center',
                     fontsize=13, fontweight='bold', color='white' if val > 0.86 else '#155724')

    fig.suptitle('Figure 7: Discriminant Validity & Construct Relationships', 
                 fontsize=20, fontweight='bold', color=NAVY, y=0.98)

    plt.tight_layout()
    plt.savefig('Figure_7_Discriminant_Validity_Heatmap.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 7 regenerated cleanly.')

# ==============================================================================
# FIGURE 8: DEMOGRAPHIC DISTRIBUTION (AMPLIFIED HEADROOM)
# ==============================================================================
def plot_figure_8():
    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    for ax in axes.flat:
        ax.grid(False)

    # 1. Age
    age_counts = df['Age'].value_counts()[['18–25', '26–35', '36–45', '46–55', 'Above 55']]
    axes[0, 0].bar(age_counts.index, age_counts.values, color=NAVY, edgecolor='black', lw=1.4)
    axes[0, 0].set_title('Age Distribution', fontsize=13.5, fontweight='bold', color=NAVY)
    axes[0, 0].set_ylabel('Respondents (N)', fontsize=11.5, fontweight='bold')
    axes[0, 0].set_ylim(0, max(age_counts.values) * 1.22)
    axes[0, 0].tick_params(axis='x', rotation=15, labelsize=9.5)
    for p in axes[0, 0].patches:
        axes[0, 0].annotate(f'{int(p.get_height())}', (p.get_x() + p.get_width() / 2., p.get_height() + 4),
                            ha='center', va='bottom', fontsize=9.5, fontweight='bold')

    # 2. Gender
    gender_counts = df['Gender'].value_counts()
    axes[0, 1].bar(gender_counts.index, gender_counts.values, color=STEEL, edgecolor='black', lw=1.4)
    axes[0, 1].set_title('Gender Distribution', fontsize=13.5, fontweight='bold', color=NAVY)
    axes[0, 1].set_ylabel('Respondents (N)', fontsize=11.5, fontweight='bold')
    axes[0, 1].set_ylim(0, max(gender_counts.values) * 1.22)
    axes[0, 1].tick_params(axis='x', rotation=15, labelsize=9.5)
    for p in axes[0, 1].patches:
        axes[0, 1].annotate(f'{int(p.get_height())}', (p.get_x() + p.get_width() / 2., p.get_height() + 4),
                            ha='center', va='bottom', fontsize=9.5, fontweight='bold')

    # 3. Work Arrangement
    arr_counts = df['Working_Arrangement'].value_counts()[['On-site', 'Hybrid', 'Remote']]
    axes[1, 0].bar(arr_counts.index, arr_counts.values, color=GREEN, edgecolor='black', lw=1.4)
    axes[1, 0].set_title('Working Arrangement', fontsize=13.5, fontweight='bold', color=NAVY)
    axes[1, 0].set_ylabel('Respondents (N)', fontsize=11.5, fontweight='bold')
    axes[1, 0].set_ylim(0, max(arr_counts.values) * 1.22)
    axes[1, 0].tick_params(axis='x', labelsize=10.5)
    for p in axes[1, 0].patches:
        axes[1, 0].annotate(f'{int(p.get_height())}', (p.get_x() + p.get_width() / 2., p.get_height() + 4),
                            ha='center', va='bottom', fontsize=9.5, fontweight='bold')

    # 4. Experience
    exp_order = ['<1 year', '1–3 years', '4–6 years', '7–10 years', 'Above 10 years']
    exp_counts = df['Work_Experience'].value_counts()[exp_order]
    axes[1, 1].bar(exp_counts.index, exp_counts.values, color=GOLD, edgecolor='black', lw=1.4)
    axes[1, 1].set_title('Work Experience Distribution', fontsize=13.5, fontweight='bold', color=NAVY)
    axes[1, 1].set_ylabel('Respondents (N)', fontsize=11.5, fontweight='bold')
    axes[1, 1].set_ylim(0, max(exp_counts.values) * 1.22)
    axes[1, 1].tick_params(axis='x', rotation=15, labelsize=9.5)
    for p in axes[1, 1].patches:
        axes[1, 1].annotate(f'{int(p.get_height())}', (p.get_x() + p.get_width() / 2., p.get_height() + 4),
                            ha='center', va='bottom', fontsize=9.5, fontweight='bold')

    fig.suptitle('Figure 8: Demographic Distribution of Respondents (N = 421)', 
                 fontsize=20, fontweight='bold', color=NAVY, y=0.98)

    plt.tight_layout()
    plt.savefig('Figure_8_Demographic_Distribution.png', dpi=800, bbox_inches='tight')
    plt.close()
    print('Figure 8 regenerated cleanly.')

if __name__ == '__main__':
    plot_figure_1()
    plot_figure_2()
    plot_figure_3()
    plot_figure_4()
    plot_figure_5()
    plot_figure_6()
    plot_figure_7()
    plot_figure_8()
    print('All 8 publication-quality figures regenerated successfully!')
